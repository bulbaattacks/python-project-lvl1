from brain_games.games.brain_gcd_game import get_gcd


def main():
    get_gcd()


if __name__ == '__main__':
    main()

