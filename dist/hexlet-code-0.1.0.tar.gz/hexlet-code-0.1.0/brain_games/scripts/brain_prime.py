#!/usr/bin/env python
from brain_games.games.brain_prime_game import is_prime


def main():
    is_prime()


if __name__ == '__main__':
    main()
