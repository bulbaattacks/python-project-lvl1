#!/usr/bin/env python
from brain_games.games.brain_even_game import is_even


def main():
    is_even()


if __name__ == '__main__':
    main()
