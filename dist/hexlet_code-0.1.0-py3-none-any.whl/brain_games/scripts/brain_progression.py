#!/usr/bin/env python
from brain_games.games.brain_progression_game import brain_progression


def main():
    brain_progression()


if __name__ == '__main__':
    main()
